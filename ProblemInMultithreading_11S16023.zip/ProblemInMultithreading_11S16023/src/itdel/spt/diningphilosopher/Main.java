/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itdel.spt.diningphilosopher;

/**
 *
 * @author JHON LIMBONG
 */
public class Main {
    public static void main(String _args[]){
        Table table = new Table(5);
        table.startDining();
    }
}
