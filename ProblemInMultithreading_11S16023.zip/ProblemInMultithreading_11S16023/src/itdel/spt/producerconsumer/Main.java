/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itdel.spt.producerconsumer;

/**
 *
 * @author JHON LIMBONG
 */
public class Main {
    public static void main(String _args[]){
        CookieShop shop = new CookieShop(3, 2, 5);
        shop.startInteracting();
    }
}
